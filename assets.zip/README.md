# Stanley – Portfolio Website

Portofolio pribadi untuk memamerkan profil profesional Stanley sebagai lulusan S1 Computer Science. Situs ini dirancang ringan, responsif, dan siap dipublikasikan melalui GitHub Pages atau layanan hosting statis lainnya.

## Fitur Utama

- **Copywriting profesional** yang merangkum ringkasan, pengalaman kerja, keahlian, proyek, pendidikan, dan pencapaian.
- **Desain modern** dengan tipografi Inter, layout responsif, dan animasi halus.
- **Mode terang/gelap** dengan preferensi yang tersimpan di `localStorage` dan sinkronisasi dengan sistem.
- **Navigasi mobile-friendly** lengkap dengan menu hamburger.
- **Aksesibilitas dasar** seperti skip link, struktur heading yang rapi, dan kontras warna yang sesuai.

## Struktur Berkas

```
/
├── index.html      # Halaman utama portofolio
├── style.css       # Styling global dan tema
├── script.js       # Kontrol tema, nav toggle, utilitas kecil
├── CV Terbaru.docx # CV versi terbaru (opsional untuk diunduh pengunjung)
└── README.md       # Dokumentasi proyek
```

## Menjalankan Secara Lokal

1. Clone repositori:
   ```bash
   git clone https://github.com/<username>/portfolio.git
   cd portfolio
   ```
2. Buka `index.html` langsung di browser, atau gunakan extension Live Server jika memakai VS Code.

## Deploy ke GitHub Pages

1. Pastikan semua perubahan sudah di-commit dan di-push ke branch `main`.
2. Masuk ke _Settings → Pages_ pada repositori GitHub.
3. Pada _Build and deployment_, pilih:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main` dengan folder `/root` (atau `/`).
4. Simpan pengaturan. GitHub akan mem-build dan menampilkan URL publik dalam beberapa menit.

## Kustomisasi

- **Konten**: sunting teks di `index.html` untuk memperbarui data pengalaman, proyek, atau kontak.
- **Gaya visual**: ubah warna dan typography di `style.css`. Variabel CSS di bagian atas memudahkan penyesuaian tema.
- **Interaktivitas**: tambahkan behavior baru ke `script.js` jika membutuhkan animasi tambahan atau integrasi form.

## Checklist Sebelum Publikasi

- [ ] Verifikasi kembali semua link proyek, LinkedIn, GitHub, dan email.
- [ ] Perbarui tautan `Unduh CV` jika ada versi PDF/terbaru.
- [ ] Lakukan pengujian pada perangkat seluler untuk memastikan tampilan responsif.
- [ ] Jalankan _PageSpeed Insights_ atau _Lighthouse_ untuk memastikan performa optimal.

Selamat menggunakan portofolio ini untuk menunjukkan kapabilitas profesional Anda! Jika ingin menambahkan fitur baru (misal blog, studi kasus mendalam, atau form kontak terintegrasi), struktur proyek ini siap dikembangkan lebih lanjut.
